# Cascading Lookup Chart

A Helm chart demonstrating the cascading conditional lookup pattern for progressive resource deployment.

## Overview

This chart implements a **cascading lookup pattern** where each resource is only created if the previous one was successfully deployed in an earlier helm upgrade. This is useful for:

- Progressive rollouts across multiple deployment cycles
- Resources with strict ordering dependencies
- Controlled, staged deployments
- Testing deployment chains

## How It Works

The chart uses Helm's `lookup` function to check if previous resources exist before creating new ones:

1. **Step 1 (ConfigMap)**: Always created on first install if enabled
2. **Step 2 (Secret)**: Only created if Step 1 ConfigMap exists (2nd upgrade)
3. **Step 3 (ServiceAccount)**: Only created if Steps 1 & 2 exist (3rd upgrade)
4. **Step 4 (Deployment)**: Only created if Steps 1, 2 & 3 exist (4th upgrade)
5. **Step 5 (Service)**: Only created if Steps 1, 2, 3 & 4 exist (5th upgrade)

## Installation

### First Deployment (Step 1)

```bash
helm install my-cascade ./cascading-lookup-chart
```

This creates:
- ✓ ConfigMap (step1-configmap)
- ✗ Other resources (dependencies not met)

### Second Deployment (Step 2)

```bash
helm upgrade my-cascade ./cascading-lookup-chart
```

This creates:
- ✓ ConfigMap (already exists)
- ✓ Secret (step2-secret) - NEW!
- ✗ Other resources (dependencies not met)

### Third Deployment (Step 3)

```bash
helm upgrade my-cascade ./cascading-lookup-chart
```

This creates:
- ✓ ConfigMap (already exists)
- ✓ Secret (already exists)
- ✓ ServiceAccount (step3-serviceaccount) - NEW!
- ✗ Other resources (dependencies not met)

### Continue Until Complete

Repeat `helm upgrade` until all 5 steps are deployed.

## Configuration

### values.yaml

```yaml
# Enable/disable the cascading pattern
cascadingLookup:
  enabled: true

# Enable/disable individual steps
step1:
  enabled: true
  
step2:
  enabled: true
  
step3:
  enabled: true
  
step4:
  enabled: true
  
step5:
  enabled: true

# Namespace for all resources
namespace: default
```

### Customizing Resources

Each step can be customized in `values.yaml`:

```yaml
step1:
  enabled: true
  configmap:
    name: step1-configmap
    data:
      message: "Step 1 completed"
      custom_key: "custom_value"

step2:
  enabled: true
  secret:
    name: step2-secret
    data:
      username: "myuser"
      password: "mypassword"
```

## Progressive Deployment Example

```bash
# Install (creates Step 1 only)
helm install my-cascade ./cascading-lookup-chart

# Check what exists
kubectl get cm,secret,sa,deploy,svc -l app.kubernetes.io/instance=my-cascade

# Upgrade to Step 2
helm upgrade my-cascade ./cascading-lookup-chart

# Upgrade to Step 3
helm upgrade my-cascade ./cascading-lookup-chart

# Upgrade to Step 4
helm upgrade my-cascade ./cascading-lookup-chart

# Upgrade to Step 5 (complete)
helm upgrade my-cascade ./cascading-lookup-chart
```

## Checking Deployment Status

```bash
# View all resources
kubectl get all -l app.kubernetes.io/instance=my-cascade

# Check cascade progress
kubectl get cm,secret,sa,deploy,svc -l app.kubernetes.io/instance=my-cascade -o custom-columns=NAME:.metadata.name,KIND:.kind,STEP:.metadata.labels.cascade-step

# Dry-run to see what will be created next
helm upgrade my-cascade ./cascading-lookup-chart --dry-run --debug
```

## Template Example

Here's how the lookup pattern works in the templates:

```yaml
{{- if and .Values.cascadingLookup.enabled .Values.step2.enabled }}
{{- $step1Exists := include "cascading-lookup.step1Exists" . }}
{{- if $step1Exists }}
---
apiVersion: v1
kind: Secret
metadata:
  name: {{ .Values.step2.secret.name }}
  # ... resource definition
{{- else }}
# Step 2 skipped: Step 1 does not exist yet
{{- end }}
{{- end }}
```

The helper function checks if the resource exists:

```yaml
{{- define "cascading-lookup.step1Exists" -}}
{{- $configmap := lookup "v1" "ConfigMap" .Values.namespace .Values.step1.configmap.name }}
{{- if $configmap }}
{{- "true" }}
{{- end }}
{{- end }}
```

## Use Cases

1. **Database Migration**: Deploy schema → seed data → application → monitoring
2. **Multi-tier Apps**: Database → cache → backend → frontend → ingress
3. **Infrastructure Setup**: Namespace → secrets → config → workload → service
4. **Compliance**: Audit logging → security policies → application → monitoring
5. **Testing Deployments**: Verify each layer before proceeding to the next

## Advanced Usage

### Skip Steps

Disable a step by setting `enabled: false`:

```yaml
step3:
  enabled: false  # Skip ServiceAccount
```

Note: Subsequent steps won't be created until this step is re-enabled.

### Custom Validation

Modify the helper functions in `_helpers.tpl` to add custom validation logic:

```yaml
{{- define "cascading-lookup.step1Exists" -}}
{{- $configmap := lookup "v1" "ConfigMap" .Values.namespace .Values.step1.configmap.name }}
{{- if $configmap }}
  {{- if $configmap.data.message }}
    {{- "true" }}
  {{- end }}
{{- end }}
{{- end }}
```

## Troubleshooting

### Resources Not Creating

Check if previous steps exist:

```bash
helm template my-cascade ./cascading-lookup-chart | grep "skipped"
```

### Reset and Start Over

```bash
helm uninstall my-cascade
kubectl delete cm,secret,sa,deploy,svc -l app.kubernetes.io/instance=my-cascade
helm install my-cascade ./cascading-lookup-chart
```

## License

This chart is provided as an example for educational purposes.
