#!/bin/bash

# Cascading Lookup Chart - Test Script
# This script demonstrates the progressive deployment pattern

set -e

CHART_PATH="./cascading-lookup-chart"
RELEASE_NAME="test-cascade"
NAMESPACE="default"

echo "========================================"
echo "Cascading Lookup Chart - Test Deployment"
echo "========================================"
echo ""

# Function to show current resources
show_resources() {
    echo ""
    echo "Current Resources:"
    echo "------------------"
    kubectl get cm,secret,sa,deploy,svc -l app.kubernetes.io/instance=$RELEASE_NAME -n $NAMESPACE 2>/dev/null || echo "No resources found yet"
    echo ""
}

# Function to wait for user
wait_for_user() {
    echo ""
    read -p "Press Enter to continue to next step..."
    echo ""
}

# Clean up any existing installation
echo "Cleaning up any existing installation..."
helm uninstall $RELEASE_NAME -n $NAMESPACE 2>/dev/null || true
kubectl delete cm,secret,sa,deploy,svc -l app.kubernetes.io/instance=$RELEASE_NAME -n $NAMESPACE 2>/dev/null || true
sleep 2

echo "✓ Cleanup complete"
echo ""
wait_for_user

# Step 1: Initial Install
echo "========================================"
echo "STEP 1: Initial Install"
echo "========================================"
echo "This will create ONLY the ConfigMap (step1)"
echo ""

helm install $RELEASE_NAME $CHART_PATH -n $NAMESPACE

show_resources
wait_for_user

# Step 2: First Upgrade
echo "========================================"
echo "STEP 2: First Upgrade"
echo "========================================"
echo "This will create the Secret (step2)"
echo "The lookup function will detect step1 exists"
echo ""

helm upgrade $RELEASE_NAME $CHART_PATH -n $NAMESPACE

show_resources
wait_for_user

# Step 3: Second Upgrade
echo "========================================"
echo "STEP 3: Second Upgrade"
echo "========================================"
echo "This will create the ServiceAccount (step3)"
echo "The lookup function will detect steps 1 & 2 exist"
echo ""

helm upgrade $RELEASE_NAME $CHART_PATH -n $NAMESPACE

show_resources
wait_for_user

# Step 4: Third Upgrade
echo "========================================"
echo "STEP 4: Third Upgrade"
echo "========================================"
echo "This will create the Deployment (step4)"
echo "The lookup function will detect steps 1, 2 & 3 exist"
echo ""

helm upgrade $RELEASE_NAME $CHART_PATH -n $NAMESPACE

show_resources
wait_for_user

# Step 5: Fourth Upgrade (Final)
echo "========================================"
echo "STEP 5: Fourth Upgrade (Final)"
echo "========================================"
echo "This will create the Service (step5)"
echo "The lookup function will detect all previous steps exist"
echo ""

helm upgrade $RELEASE_NAME $CHART_PATH -n $NAMESPACE

show_resources

echo ""
echo "========================================"
echo "✓ DEPLOYMENT COMPLETE!"
echo "========================================"
echo ""
echo "All 5 steps have been deployed progressively."
echo ""
echo "Verify with:"
echo "  kubectl get cm,secret,sa,deploy,svc -l app.kubernetes.io/instance=$RELEASE_NAME"
echo ""
echo "View cascade order:"
echo "  kubectl get cm,secret,sa,deploy,svc -l app.kubernetes.io/instance=$RELEASE_NAME -o custom-columns=NAME:.metadata.name,KIND:.kind,STEP:.metadata.labels.cascade-step"
echo ""
echo "Cleanup:"
echo "  helm uninstall $RELEASE_NAME"
echo ""
