# Cascading Lookup Pattern - Quick Reference

## Pattern Overview

```
Install     → ConfigMap created
Upgrade 1   → Secret created (if ConfigMap exists)
Upgrade 2   → ServiceAccount created (if ConfigMap + Secret exist)
Upgrade 3   → Deployment created (if all previous exist)
Upgrade 4   → Service created (if all previous exist)
```

## Key Implementation Details

### 1. Helper Functions (_helpers.tpl)

```yaml
{{- define "cascading-lookup.step1Exists" -}}
{{- $configmap := lookup "v1" "ConfigMap" .Values.namespace .Values.step1.configmap.name }}
{{- if $configmap }}
{{- "true" }}
{{- end }}
{{- end }}
```

### 2. Template Pattern (stepN-*.yaml)

```yaml
{{- if and .Values.cascadingLookup.enabled .Values.stepN.enabled }}
{{- $step1Exists := include "cascading-lookup.step1Exists" . }}
{{- $step2Exists := include "cascading-lookup.step2Exists" . }}
# ... check all previous steps

{{- if and $step1Exists $step2Exists ... }}
---
# Resource definition here
{{- else }}
# Comment explaining why resource is skipped
{{- end }}
{{- end }}
```

## Usage Commands

```bash
# Install (creates first resource only)
helm install my-release ./cascading-lookup-chart

# Upgrade to next step
helm upgrade my-release ./cascading-lookup-chart

# Check what will be created (dry-run)
helm upgrade my-release ./cascading-lookup-chart --dry-run --debug

# View all cascade resources
kubectl get cm,secret,sa,deploy,svc -l app.kubernetes.io/instance=my-release

# View with cascade step labels
kubectl get all -l app.kubernetes.io/instance=my-release \
  -o custom-columns=NAME:.metadata.name,KIND:.kind,STEP:.metadata.labels.cascade-step
```

## Customization Examples

### Simple: Change Resource Names

```yaml
step1:
  enabled: true
  configmap:
    name: my-custom-configmap  # Change name
    data:
      mykey: myvalue            # Custom data
```

### Advanced: Add More Steps

1. Add helper function in `_helpers.tpl`:
```yaml
{{- define "cascading-lookup.step6Exists" -}}
{{- $ingress := lookup "networking.k8s.io/v1" "Ingress" .Values.namespace .Values.step6.ingress.name }}
{{- if $ingress }}{{- "true" }}{{- end }}
{{- end }}
```

2. Create template `step6-ingress.yaml`:
```yaml
{{- if and .Values.cascadingLookup.enabled .Values.step6.enabled }}
{{- $allPreviousExist := and 
  (include "cascading-lookup.step1Exists" .)
  (include "cascading-lookup.step2Exists" .)
  (include "cascading-lookup.step3Exists" .)
  (include "cascading-lookup.step4Exists" .)
  (include "cascading-lookup.step5Exists" .) }}
{{- if $allPreviousExist }}
---
apiVersion: networking.k8s.io/v1
kind: Ingress
# ... ingress definition
{{- end }}
{{- end }}
```

3. Add to `values.yaml`:
```yaml
step6:
  enabled: true
  ingress:
    name: step6-ingress
    host: example.com
```

### Conditional Dependencies

Instead of requiring ALL previous steps, require specific ones:

```yaml
{{- if and .Values.cascadingLookup.enabled .Values.stepN.enabled }}
{{- $step1Exists := include "cascading-lookup.step1Exists" . }}
{{- $step3Exists := include "cascading-lookup.step3Exists" . }}
{{- if and $step1Exists $step3Exists }}
# This resource only needs steps 1 and 3, not 2
{{- end }}
{{- end }}
```

## Troubleshooting

### Resource not creating?

```bash
# Check which dependencies are missing
helm template my-release ./cascading-lookup-chart | grep -A5 "skipped"
```

### Start over?

```bash
helm uninstall my-release
kubectl delete cm,secret,sa,deploy,svc -l app.kubernetes.io/instance=my-release
helm install my-release ./cascading-lookup-chart
```

### View lookup results in real-time?

```bash
# Dry-run shows which resources will be created
helm upgrade my-release ./cascading-lookup-chart --dry-run --debug | grep -E "(Step|skipped|EXISTS)"
```

## When to Use This Pattern

✅ **Good for:**
- Progressive rollouts requiring validation between steps
- Deployments with strict ordering requirements
- Staged infrastructure setup
- Testing dependency chains
- Compliance scenarios requiring audit trails

❌ **Not ideal for:**
- Simple applications with no dependencies
- Resources that can be created in any order
- When you need all resources immediately
- Development environments requiring fast iteration

## Alternative Patterns

If cascading lookups are too complex, consider:

1. **Helm Hooks**: Use pre-install/post-install hooks
2. **Init Containers**: Dependencies within a single pod
3. **Operators**: Custom controllers managing dependencies
4. **ArgoCD Sync Waves**: Wave-based ordering in GitOps
5. **Job Dependencies**: Jobs with initContainers or sidecars
