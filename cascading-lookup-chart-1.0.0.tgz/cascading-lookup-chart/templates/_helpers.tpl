{{/*
Expand the name of the chart.
*/}}
{{- define "cascading-lookup.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "cascading-lookup.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "cascading-lookup.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "cascading-lookup.labels" -}}
helm.sh/chart: {{ include "cascading-lookup.chart" . }}
{{ include "cascading-lookup.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "cascading-lookup.selectorLabels" -}}
app.kubernetes.io/name: {{ include "cascading-lookup.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Check if Step 1 resource exists (ConfigMap)
Returns: true if exists, empty otherwise
*/}}
{{- define "cascading-lookup.step1Exists" -}}
{{- $configmap := lookup "v1" "ConfigMap" .Values.namespace .Values.step1.configmap.name }}
{{- if $configmap }}
{{- "true" }}
{{- end }}
{{- end }}

{{/*
Check if Step 2 resource exists (Secret)
Returns: true if exists, empty otherwise
*/}}
{{- define "cascading-lookup.step2Exists" -}}
{{- $secret := lookup "v1" "Secret" .Values.namespace .Values.step2.secret.name }}
{{- if $secret }}
{{- "true" }}
{{- end }}
{{- end }}

{{/*
Check if Step 3 resource exists (ServiceAccount)
Returns: true if exists, empty otherwise
*/}}
{{- define "cascading-lookup.step3Exists" -}}
{{- $sa := lookup "v1" "ServiceAccount" .Values.namespace .Values.step3.serviceaccount.name }}
{{- if $sa }}
{{- "true" }}
{{- end }}
{{- end }}

{{/*
Check if Step 4 resource exists (Deployment)
Returns: true if exists, empty otherwise
*/}}
{{- define "cascading-lookup.step4Exists" -}}
{{- $deployment := lookup "apps/v1" "Deployment" .Values.namespace .Values.step4.deployment.name }}
{{- if $deployment }}
{{- "true" }}
{{- end }}
{{- end }}

{{/*
Check if Step 5 resource exists (Service)
Returns: true if exists, empty otherwise
*/}}
{{- define "cascading-lookup.step5Exists" -}}
{{- $service := lookup "v1" "Service" .Values.namespace .Values.step5.service.name }}
{{- if $service }}
{{- "true" }}
{{- end }}
{{- end }}
