# krt-cleaner-chart
This Hellm Chart is designed to release a CronJob that monitors and cleans up Helm-managed resources related to a Krateo composition that are no longer transitioning and are all ready. It uses `kubectl`, `helm`, and `jq` inside an Alpine-based container to inspect Helm releases and annotate related Kubernetes compositions to track cleanup attempts.

## What It Does

This CronJob performs the following:

1. **Checks Helm release status:**
   - If `failed` → exit with error.
   - If `deployed` → proceed to check resource readiness.
2. **Validates readiness of Helm-managed resources:**
   - Uses Helm and Kubernetes to iterate through resources.
   - Checks for resources with a `Ready` condition that is `False`.
   - If any are not ready → annotates the "composition" and exits.
3. **Tracks cleanup attempts:**
   - Uses two annotations:
     - `backbone.cloud/cr-cleanup-job-count`: number of failed cleanup attempts.
     - `backbone.cloud/cr-cleanup-job-last-cr-timestamp`: last known resource transition time.
   - Compares current and past transition timestamps.
   - Increments or resets counter accordingly.
4. **Performs cleanup if conditions are met:**
   - Deletes the Helm release if:
     - `cr-cleanup-job-count >= 3`
     - AND last transition timestamp hasn't changed since last check.
   - Annotates the composition to pause further operations via: `krateo.io/paused=true`.

---

## Required Variables

Before running, ensure the following environment variables are set in the container:

| Variable     | Description                          |
|--------------|--------------------------------------|
| `compositionType`   | Composition type object to annotate |
| `serviceAccountName`   | Name of the Kubernetes SA used by the job to operate|

These can be passed via values.yaml file.

---

## Annotations Used

- `backbone.cloud/cr-cleanup-job-count`: Counter to track failed or unchanged cleanup attempts.
- `backbone.cloud/cr-cleanup-job-last-cr-timestamp`: Timestamp of the last state transition of the youngest resource.
- `krateo.io/paused=true`: Optional annotation to mark the composition as paused (used before deleting Helm release).

---

## When It Exits Early

- Helm release is in `failed` state.
- One or more Helm resources are not ready.
- Required annotations or environment variables are missing.
- Helm release is in an unexpected state.

---