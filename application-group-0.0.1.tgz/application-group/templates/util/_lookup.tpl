{{- /*
    Get Composition environment from CompositionDefinition annotation's resource
*/ -}}
{{- define "application-group.getCompositionEnvCached" -}}
    {{- $ := index . 0 }}
    {{- $arg := index . 1 }}
    {{- $compositionEnvKey := "CompositionEnv" }}
    {{- if hasKey $ $compositionEnvKey }}
        {{- /* If this partial template has been already called, return cached result */ -}}
        {{- $environment := get $ $compositionEnvKey }}
        {{- $environment | toYaml }}
    {{- else }}
        {{- /* Otherwise, lookup for CompositionDefinition on the cluster */ -}}
        {{- $compositionDef := dict }}
        {{- $namespace := include "application-group.compositionNamespace" $ }}
        {{- $resource := $arg }}
        {{- $slices := splitList "/" $arg }}
        {{- if eq (len $slices) 2 }}
            {{- $namespace = first $slices }}
            {{- $resource = last $slices }}
        {{- end }}
        {{- $compositionDef = lookup "core.krateo.io/v1alpha1" "CompositionDefinition" $namespace $resource }}
        {{- /* Try to extract environment annotation from CompositionDefinition */ -}}
        {{- $environmentAnnotation := "backbone.cloud/environment" }}
        {{- $compositionDefEnvPresent := hasKey (($compositionDef.metadata | default (dict)).annotations) $environmentAnnotation }}
        {{- $environment := dict }}
        {{- if $compositionDefEnvPresent }}
            {{- /* If CompositionDefinition does have environment annotation, extract the value as dict and update root context */ -}}
            {{- $compositionDefEnv := get $compositionDef.metadata.annotations $environmentAnnotation | default "{}" }}
            {{- $compositionDefEnvNotEmpty := not (empty $compositionDefEnv) }}
            {{- $compositionDefEnvIsDict := eq (typeOf ($compositionDefEnv | fromJson)) "map[string]interface {}" }}
            {{- if and $compositionDefEnv (and $compositionDefEnvNotEmpty $compositionDefEnvIsDict) }}
                {{- $environment = $compositionDefEnv | fromJson }}
                {{- $_ := set $ $compositionEnvKey $environment }}
                {{- $environment | toYaml }}
            {{- else }}
                {{- $_ := set $ $compositionEnvKey $environment }}
                {{- $environment | toYaml }}
            {{- end }}
        {{- else }}
            {{- /* If CompositionDefinition does not have environment annotataion, update root context and return empty dict */ -}}
            {{- $_ := set $ $compositionEnvKey $environment }}
            {{- $environment | toYaml }}
        {{- end }}
    {{- end }}
{{- end -}}

{{- /*
	Get TeamProject object from default composition namespace
	@arg string the TeamProject's name
	[TBD] preserve relative context passing two arguments
*/ -}}
{{- define "application-group.getTeamProject" -}}
	{{- $namespace := include "application-group.compositionNamespace" . }}
	{{- $resource := . }}
	{{- $slices := splitList "/" . }}
	{{- if eq (len $slices) 2 }}
		{{- $namespace = first $slices }}
		{{- $resource = last $slices }}
	{{- end }}
	{{- /* using default composition namespace even if TemProject resources are not namespaced */ -}}
	{{- $teamProject := lookup "azuredevops.krateo.io/v1alpha1" "TeamProject" $namespace $resource }}
	{{- /* check up to three layers of existence */ -}}
	{{- $isTeamProjectCreated := and $teamProject ($teamProject.status | default (dict)).id }}
	{{- if $isTeamProjectCreated }}
		{{- $teamProject | toYaml }}
	{{- else }}
		{{- dict | toYaml }}
	{{- end }}
{{- end -}}

{{- /*
	Get TeamProject object from default composition namespace and insert the result in global context $
	@arg string the TeamProject's name
*/ -}}
{{- define "application-group.getTeamProjectCached" -}}
	{{- $teamProjectKey := printf "teamProject-%s" . }}
	{{- if hasKey $ $teamProjectKey }}
		# [TBD] do stuff
	{{- else }}
		# [TBD] do stuff
		{{- $teamProject := lookup "azuredevops.krateo.io/v1alpha1" "TeamProject" (include "application-group.compositionNamespace" .) . }}
		{{- $_ := set $ $teamProjectKey $teamProject }}
		{{- get $ $teamProjectKey | toYaml }}
	{{- end }}
{{- end -}}

{{- /*
	Get GitRepository object from default composition namespace
	@arg string the GitRepository's name
*/ -}}
{{- define "application-group.getGitRepository" -}}
	{{- $namespace := include "application-group.compositionNamespace" . }}
	{{- $resource := . }}
	{{- $slices := splitList "/" . }}
	{{- if eq (len $slices) 2 }}
		{{- $namespace = first $slices }}
		{{- $resource = last $slices }}
	{{- end }}
	{{- /* using default composition namespace even if GitRepository resources are not namespaced */ -}}
	{{- $gitRepository := lookup "azuredevops.krateo.io/v1alpha1" "GitRepository" $namespace $resource }}
	{{- /* check up to three layers of existence */ -}}
	{{- $isGitRepositoryCreated := and $gitRepository ($gitRepository.status | default (dict)).remoteUrl }}
	{{- if $isGitRepositoryCreated }}
		{{- $gitRepository | toYaml }}
	{{- else }}
		{{- dict | toYaml }}
	{{- end }}
{{- end -}}

{{- /*
	Get Repo object from default composition namespace
	@arg string the Repo's name
*/ -}}
{{- define "application-group.getRepo" -}}
	{{- $namespace := include "application-group.compositionNamespace" . }}
	{{- $resource := . }}
	{{- $slices := splitList "/" . }}
	{{- if eq (len $slices) 2 }}
		{{- $namespace = first $slices }}
		{{- $resource = last $slices }}
	{{- end }}
	{{- /* using default composition namespace even if Repo resources are not namespaced */ -}}
	{{- $repo := lookup "git.krateo.io/v1alpha1" "Repo" $namespace $resource }}
	{{- /* check up to three layers of existence */ -}}
	{{- $isRepoCreated := and $repo ($repo.status | default (dict)).targetCommitId }}
	{{- if $isRepoCreated }}
		{{- $repo | toYaml }}
	{{- else }}
		{{- dict | toYaml }}
	{{- end }}
{{- end -}}

{{- /*
	Get Endpoint object from default composition namespace
	@arg string the Endpoint's name
*/ -}}
{{- define "application-group.getEndpoint" -}}	
	{{- $namespace := include "application-group.compositionNamespace" . }}
	{{- $resource := . }}
	{{- $slices := splitList "/" . }}
	{{- if eq (len $slices) 2 }}
		{{- $namespace = first $slices }}
		{{- $resource = last $slices }}
	{{- end }}
	{{- /* using default composition namespace even if Endpoint resources are not namespaced */ -}}
	{{- $endpoint := lookup "azuredevops.krateo.io/v1alpha1" "Endpoint" $namespace $resource }}
	{{- /* check up to three layers of existence */ -}}
	{{- $isEndpointCreated := and $endpoint ($endpoint.status | default (dict)).id }}
	{{- if $isEndpointCreated }}
		{{- $endpoint | toYaml }}
	{{- else }}
		{{- dict | toYaml }}
	{{- end }}
{{- end -}}

{{- /*
	Get Users object from default composition namespace
	@arg string the Users's name
*/ -}}
{{- define "application-group.getRawUser" -}}
	{{- $namespace := include "application-group.compositionNamespace" . }}
	{{- $resource := . }}
	{{- $slices := splitList "/" . }}
	{{- if eq (len $slices) 2 }}
		{{- $namespace = first $slices }}
		{{- $resource = last $slices }}
	{{- end }}
	{{- /* using default composition namespace even if Users resources are not namespaced */ -}}
	{{- $user := lookup "azuredevops.krateo.io/v1alpha1" "Users" $namespace $resource }}
	{{- $user | toYaml }}
{{- end -}}

{{- /*
	Get Users object from default composition namespace
	@arg string the Users's name
*/ -}}
{{- define "application-group.getUser" -}}
	{{- $namespace := include "application-group.compositionNamespace" . }}
	{{- $resource := . }}
	{{- $slices := splitList "/" . }}
	{{- if eq (len $slices) 2 }}
		{{- $namespace = first $slices }}
		{{- $resource = last $slices }}
	{{- end }}
	{{- /* using default composition namespace even if Users resources are not namespaced */ -}}
	{{- $user := lookup "azuredevops.krateo.io/v1alpha1" "Users" $namespace $resource }}
	{{- /* check up to three layers of existence */ -}}
	{{- $isUserCreated := and $user ($user.status | default (dict)).descriptor }}
	{{- if $isUserCreated }}
		{{- $user | toYaml }}
	{{- else }}
		{{- dict | toYaml }}
	{{- end }}
{{- end -}}

{{- /*
	Get Group object from default composition namespace
	@arg string the Group's name
*/ -}}
{{- define "application-group.getGroup" -}}
	{{- $namespace := include "application-group.compositionNamespace" . }}
	{{- $resource := . }}
	{{- $slices := splitList "/" . }}
	{{- if eq (len $slices) 2 }}
		{{- $namespace = first $slices }}
		{{- $resource = last $slices }}
	{{- end }}
	{{- /* using default composition namespace even if Group resources are not namespaced */ -}}
	{{- $group := lookup "azuredevops.krateo.io/v1alpha1" "Groups" $namespace $resource }}
	{{- /* check up to three layers of existence */ -}}
	{{- $isGroupCreated := and $group ($group.status | default (dict)).descriptor }}
	{{- if $isGroupCreated }}
		{{- $group | toYaml }}
	{{- else }}
		{{- dict | toYaml }}
	{{- end }}
{{- end -}}

{{- /*
	Get Team object from default composition namespace
	@arg string the Team's name
*/ -}}
{{- define "application-group.getTeam" -}}
	{{- $namespace := include "application-group.compositionNamespace" . }}
	{{- $resource := . }}
	{{- $slices := splitList "/" . }}
	{{- if eq (len $slices) 2 }}
		{{- $namespace = first $slices }}
		{{- $resource = last $slices }}
	{{- end }}
	{{- /* using default composition namespace even if Team resources are not namespaced */ -}}
	{{- $team := lookup "azuredevops.krateo.io/v1alpha1" "Team" $namespace $resource }}
	{{- /* check up to three layers of existence */ -}}
	{{- $isTeamCreated := and $team ($team.status | default (dict)).descriptor }}
	{{- if $isTeamCreated }}
		{{- $team | toYaml }}
	{{- else }}
		{{- dict | toYaml }}
	{{- end }}
{{- end -}}

{{- /*
	Get AppProject object from default composition namespace
	@arg string the AppProject's name
*/ -}}
{{- define "application-group.getAppProject" -}}
	{{- $namespace := include "application-group.compositionNamespace" . }}
	{{- $resource := . }}
	{{- $slices := splitList "/" . }}
	{{- if eq (len $slices) 2 }}
		{{- $namespace = first $slices }}
		{{- $resource = last $slices }}
	{{- end }}
	{{- /* using default composition namespace even if AppProject resources are not namespaced */ -}}
	{{- $appProject := lookup "argoproj.io/v1alpha1" "AppProject" $namespace $resource }}
	{{- /* check up to three layers of existence */ -}}
	{{- $isAppProjectCreated := and $appProject ($appProject.metadata | default (dict)).uid }}
	{{- if $isAppProjectCreated }}
		{{- $appProject | toYaml }}
	{{- else }}
		{{- dict | toYaml }}
	{{- end }}
{{- end -}}

{{- /*
	Get Secret object from default composition namespace
	@arg string the Secret's name
*/ -}}
{{- define "application-group.getSecret" -}}
	{{- $namespace := include "application-group.compositionNamespace" . }}
	{{- $resource := . }}
	{{- $slices := splitList "/" . }}
	{{- if eq (len $slices) 2 }}
		{{- $namespace = first $slices }}
		{{- $resource = last $slices }}
	{{- end }}
	{{- $secret := lookup "v1" "Secret" $namespace $resource }}
	{{- /* check up to three layers of existence */ -}}
	{{- $isSecretCreated := and $secret ($secret.metadata | default (dict)).uid }}
	{{- if $isSecretCreated }}
		{{- $secret | toYaml }}
	{{- else }}
		{{- dict | toYaml }}
	{{- end }}
{{- end -}}

{{- /*
    Get ADGroup object from default composition namespace
    @arg string the ADGroup's displayName
*/ -}}
{{- define "application-group.getADGroup" -}}
    {{- $namespace := include "application-group.compositionNamespace" . }}
    {{- $resource := . }}
    {{- $slices := splitList "/" . }}
    {{- if eq (len $slices) 2 }}
        {{- $namespace = first $slices }}
        {{- $resource = last $slices }}
    {{- end }}
    {{- $adGroup := lookup "ad.krateo.io/v1alpha1" "ADGroup" $namespace $resource }}
    {{- /* check up to three layers of existence */ -}}
    {{- $isADGroupCreated := and $adGroup ($adGroup.status | default (dict)).id }}
    {{- if $isADGroupCreated }}
        {{- $adGroup | toYaml }}
    {{- else }}
        {{- dict | toYaml }}
    {{- end }}
{{- end -}}

{{- /*
    Get Microsoft Entra ID Group object from default composition namespace
    @arg string the Graph Group's displayName
*/ -}}
{{- define "application-group.getGraphGroup" -}}
apiVersion: graph.sella.cloud/v1alpha1
kind: Group
metadata:
  name: test-group
  namespace: test-namespace
status:
  id: "hardcoded-test-id-123"
{{- end -}}
