{{- /*
	Debug level
	@return integer
*/ -}}
{{- define "application-group.debug" -}}
	{{- $debug := 0 }}
	{{- $debug }}
{{- end -}}



{{- /*
	Create chart name and version as used by the chart label.
*/ -}}
{{- define "application-group.chart" -}}
	{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end -}}

{{- /*
	Common labels
*/ -}}
{{- define "application-group.labels" -}}
helm.sh/chart: {{ include "application-group.chart" . | quote }}
{{ include "application-group.selectorLabels" . }}
	{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
	{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service | quote }}
{{- end -}}

{{- /*
	Common Krateo annotations
*/ -}}
{{- define "application-group.krateoAnnotations" -}}
krateo.io/connector-verbose: {{ gt (include "application-group.debug" . | int) 0 | ternary true false | quote }}
{{- end -}}

{{- /*
  Common Ansible annotations (Operator SDK)
*/ -}}
{{- define "application-group.ansibleAnnotations" -}}
{{- /* ref@ https://sdk.operatorframework.io/docs/building-operators/ansible/reference/advanced_options */ -}}
ansible.sdk.operatorframework.io/verbosity: "0"
ansible.sdk.operatorframework.io/reconcile-period: "1200s"
{{- end -}}

{{- /*
	Management policy annotation for Krateo resource
*/ -}}
{{- define "application-group.krateoManagementPolicy" -}}
	{{- if eq . "observe" -}}
krateo.io/management-policy: "observe"
	{{- else if eq . "update" -}}
krateo.io/management-policy: "observe-create-update"
	{{- end -}}
{{- end -}}

{{- /*
	Selector labels
*/ -}}
{{- define "application-group.selectorLabels" -}}
app.kubernetes.io/name: {{ .Values.applicationGroupName | quote }}
app.kubernetes.io/instance: {{ .Release.Name | quote }}
{{- end -}}

{{- /*
	Krateo namespace
*/ -}}
{{- define "application-group.krateoNamespace" -}}
krateo-system
{{- end -}}

{{- /*
  ArgoCD namespace
*/ -}}
{{- define "application-group.argocdNamespace" -}}
krateo-system
{{- end -}}

{{- /*
	Default namespace
*/ -}}
{{- define "application-group.compositionNamespace" -}}
{{- /* if using the following variant be sure to call this partial template with "." argument */ -}}
{{- /* .Chart.Name */ -}}
application-group
{{- end -}}

{{- /*
  Default composition name
*/ -}}
{{- define "application-group.compositionName" -}}
{{- /* .Chart.Name */ -}}
application-group
{{- end -}}

{{- /*
  Default composition short name
*/ -}}
{{- define "application-group.compositionNameShort" -}}
{{- /* .Chart.Name */ -}}
ag
{{- end -}}

{{- /*
	Default composition resources prefix
*/ -}}
{{- define "application-group.compositionResourcePrefix" -}}
{{ printf "%s-%s" (include "application-group.compositionNameShort" .) .Release.Name }}
{{- end -}}

{{- /*
	Azure DevOps Endpoint secret reference
*/ -}}
{{- define "application-group.adoEndpointSecretRef" -}}
key: "token"
name: "azuredevops-endpoint"
namespace: {{ include "application-group.compositionNamespace" . | quote }}
{{- end -}}

{{- /*
  Microsoft common parameters
  @return list of string
  @deprecated
*/ -}}
{{- define "application-group.adCommonParameters" -}}
tenantId: "91b02abd-daec-432a-8ee4-b5137910aca6"
tokenSecretRef:
  name: "ad-credentials"
  namespace: {{ include "application-group.compositionNamespace" . | quote }}
  client_id: "client_id"
  client_secret: "client_secret"
{{- end -}}

{{- /*
  Jira tickets' common parameters
  @return list of string
*/ -}}
{{- define "application-group.jira.secretRef" -}}
name: "jira-credentials"
namespace: {{ include "application-group.compositionNamespace" . | quote }}
{{- end -}}

{{- /*
  Microsoft Entra ID krateo-msgraph-provider secret
  @return list of string
*/ -}}
{{- define "application-group.graphSecret" -}}
name: "msgraph-credentials"
namespace: {{ include "application-group.compositionNamespace" . | quote }}
{{- end -}}

{{- /*
	ConnectorConfig reference
*/ -}}
{{- define "application-group.connectorConfigRef" -}}
name: "connector-config"
namespace: {{ include "application-group.compositionNamespace" . | quote }}
{{- end -}}

{{- /*
	Azure DevOps default project reference
*/ -}}
{{- define "application-group.projectRef" -}}
name: {{ include "application-group.compositionResourcePrefix" . | printf "%s" | quote }}
namespace: {{ include "application-group.compositionNamespace" . | quote }}
{{- end -}}

{{- /*
	Azure DevOps BSE-ArchitetturaIT project reference
*/ -}}
{{- define "application-group.projectRefBseArchitettura" -}}
name: {{ include "application-group.compositionResourcePrefix" . | printf "%s-bsearchitettura" | quote }}
namespace: {{ include "application-group.compositionNamespace" . | quote }}
{{- end -}}

{{- /*
	Azure DevOps BSE-ToolchainDevOps project reference
*/ -}}
{{- define "application-group.projectRefBseToolchaindevops" -}}
name: {{ include "application-group.compositionResourcePrefix" . | printf "%s-bsetoolchaindevops" | quote }}
namespace: {{ include "application-group.compositionNamespace" . | quote }}
{{- end -}}

{{- /*
	Available environment list
	@return list of string
*/ -}}
{{- define "application-group.environmentList" -}}
- "dev"
- "tst"
- "uat" 
- "pro"
{{- end -}}

{{- /*
  Azure default organization
*/ -}}
{{- define "application-group.organization" -}}
  {{- $resource := printf "%s/%s" (include "application-group.compositionName" .) (include "application-group.compositionNamespace" .) }}
  {{- (include "application-group.getCompositionEnvCached" (list $ $resource) | fromYaml).organization | default "krateo-sandbox-dev" }}
{{- end -}}

{{- /*
  Default environment
*/ -}}
{{- define "application-group.environment" -}}
  {{- $resource := printf "%s/%s" (include "application-group.compositionName" .) (include "application-group.compositionNamespace" .) }}
  {{- (include "application-group.getCompositionEnvCached" (list $ $resource) | fromYaml).environment | default "dev" }}
{{- end -}}

{{- /*
	Branches list to create
	@return list of string
*/ -}}
{{- define "application-group.branchList" -}}
- "develop"
- "release"
{{- end -}}

{{- /*
	Strategies list
	@return list of string
*/ -}}
{{- define "application-group.strategyList" -}}
- "ci"
- "cd"
- "promotion"
{{- end -}}

{{- /*
	Map for Application Group Project pipeline repository skeleton global
	@return map of string
*/ -}}
{{- define "application-group.repo.pipeline.global" -}}
from:
  url: "https://centrico@dev.azure.com/centrico/BSE-ToolchainDevOps/_git/skt-applicationgroup"
  path:  "pipeline-global"
  branch: {{ include "application-group.environment" . | quote }}
to:
  url: ""
  path: ""
  branch: "main"
{{- end -}}

{{- /*
	Map for Application Group pipeline repository skeleton elastic
	@return map of string
*/ -}}
{{- define "application-group.repo.pipeline.elastic" -}}
from:
  url: "https://centrico@dev.azure.com/centrico/BSE-ToolchainDevOps/_git/fev2-applicationgroup-infra"
  path: "src/skeleton/pipeline"
  branch: {{ include "application-group.environment" . | quote }}
to:
  url: ""
  path: "elastic"
  branch: "main"
{{- end -}}

{{- /*
	Map for Application Group elastic-infra Helm Chart repository skeleton
	@return map of string
*/ -}}
{{- define "application-group.repo.elastic-infra" -}}
from:
  url: "https://centrico@dev.azure.com/centrico/BSE-ToolchainDevOps/_git/fev2-applicationgroup-infra"
  path: "src/skeleton/elastic-infra"
  branch: {{ include "application-group.environment" . | quote }}
to:
  url: ""
  path: ""
  branch: ""
{{- end -}}

{{- /*
	Map for Application Group elastic repository skeleton
	@return map of string
*/ -}}
{{- define "application-group.repo.elastic" -}}
from:
  url: "https://centrico@dev.azure.com/centrico/BSE-ToolchainDevOps/_git/fev2-applicationgroup-infra"
  path: "src/skeleton/elastic"
  branch: {{ include "application-group.environment" . | quote }}
to:
  url: ""
  path: ""
  branch: ""
{{- end -}}

{{- /*
	AAD user for Centrico
	@return string
*/ -}}
{{- define "application-group.user.centrico" -}}
azdevopsconn@centrico.tech
{{- end -}}

{{- /*
	List of Service Connection name from BSE-ToolchainDevOps to share
*/ -}}
{{- define "application-group.endpointsToShare" -}}
{{- $resource := printf "%s/%s" (include "application-group.compositionName" .) (include "application-group.compositionNamespace" .) -}}
- {{ (include "application-group.getCompositionEnvCached" (list $ $resource) | fromYaml).dockerServiceConnection | default "test-connection-docker" | quote }}
- {{ (include "application-group.getCompositionEnvCached" (list $ $resource) | fromYaml).pbiServiceConnectionUser | default "test-connection-pbi-user" | quote }}
- {{ (include "application-group.getCompositionEnvCached" (list $ $resource) | fromYaml).pbiServiceConnectionSp | default "test-connection-pbi-sp" | quote }}
{{- end -}}

{{- /*
	AKS endpoint URL
*/ -}}
{{- define "application-group.aksEndpointUrl" -}}
	{{- $resource := printf "%s/%s" (include "application-group.compositionName" .) (include "application-group.compositionNamespace" .) }}
  {{- (include "application-group.getCompositionEnvCached" (list $ $resource) | fromYaml).aksEndpointUrl | default "https://dev-krt-krateo-001.privatelink.westeurope.azmk8s.io:443" }}
{{- end -}}

{{- /*
	Azure DevOps Agent Pool for Centrico
	@return string
*/ -}}
{{- define "application-group.agentPool" -}}
	{{- $resource := printf "%s/%s" (include "application-group.compositionName" .) (include "application-group.compositionNamespace" .) }}
  {{- (include "application-group.getCompositionEnvCached" (list $ $resource) | fromYaml).agentPool | default "CentricoPrivateAzure" }}
{{- end -}}

{{- define "application-group.normalizedName" -}}
{{- /* ref@ https://github.com/Masterminds/sprig/blob/master/docs/strings.md#regexreplaceall-mustregexreplaceall */ -}}
{{- /* printf "%s" (regexReplaceAll "\\W+" .Values.applicationGroupName "_" | upper) */ -}}
{{ printf "%s" (.Values.applicationGroupName | snakecase | upper) }}
{{- end -}}

{{- /*
  List of MS Entra ID Group definitions
  @return list of obects
*/ -}}
{{- define "application-group.graph.groups" -}}
- name: {{ include "application-group.normalizedName" . | printf "AG_%s_DEVELOPERS" | upper | quote }}
  description: "developers"
  owners:
    - field: "mail"
      value: "KrateoMaster@oa.centrico.tech"
      type: "user"
  members:
  {{- range $index, $user := .Values.developersList }}
    - field: "mail"
      value: {{ . | quote }}
      type: "user"
  {{- end }}
- name: {{ include "application-group.normalizedName" . | printf "AG_%s_APPROVERS" | upper | quote }}
  description: "approvers"
  owners:
    - field: "mail"
      value: "KrateoMaster@oa.centrico.tech"
      type: "user"
  members:
  {{- range $index, $user := .Values.approversList }}
    - field: "mail"
      value: {{ . | quote }}
      type: "user"
  {{- end }}
- name: {{ include "application-group.normalizedName" . | printf "AG_%s_PR_APPROVERS" | upper |quote }}
  description: "pr-approvers"
  owners:
    - field: "mail"
      value: "KrateoMaster@oa.centrico.tech"
      type: "user"
  members:
  {{- range $index, $user := .Values.prApproversList }}
    - field: "mail"
      value: {{ . | quote }}
      type: "user"
  {{- end }}
{{- end -}}

{{- /*
  Jira ticket ad groups
*/ -}}
{{- define "application-group.jiraTicketAdGroups" -}}
name: "ad-groups"
type: "entra-id-grp"
scope: "AD Group for Azure DevOps Application Group"
body:
  project_key: "GBSITGESTPDL"
  issue_type_name: "Nuova Implementazione"
  summary: "[AG_{{ include "application-group.normalizedName" . }}] Creazione user group AD per Azure DevOps Application Group"
  description: "Buongiorno,\r\n\r\nSi notifica la creazione dei seguenti User Group / Distribution List in Active Directory tramite automazione Krateo.\r\n\r\n\r\n\r\nUser Group AG_{{ include "application-group.normalizedName" . }}_DEVELOPERS:\r\n\r\n{{- range $index, $user := .Values.developersList }}- {{ . }}\r\n\r\n{{- end }}\r\n\r\n\r\n\r\nUser Group AG_{{ include "application-group.normalizedName" . }}_APPROVERS:\r\n\r\n{{- range $index, $user := .Values.approversList }}- {{ . }}\r\n\r\n{{- end }}\r\n\r\n\r\n\r\nUser Group AG_{{ include "application-group.normalizedName" . }}_PR_APPROVERS:\r\n\r\n{{- range $index, $user := .Values.prApproversList }}- {{ . }}\r\n\r\n{{- end }}"
{{- end -}}

{{- /*
  List of Jira tickets' parameters
  @return list of objects
*/ -}}
{{- define "application-group.tickets" -}}
  {{- $ticketsList := list }}
  {{- /* Add the ad-groups ticket to the list */ -}}
  {{- $ticketsList = append $ticketsList (include "application-group.jiraTicketAdGroups" . | fromYaml) }}
  {{- $ticketsList | toYaml }}
{{- end -}}