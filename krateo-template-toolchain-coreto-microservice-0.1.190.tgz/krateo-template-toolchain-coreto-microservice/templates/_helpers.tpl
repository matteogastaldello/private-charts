{{- define "azure-project-name.trim" -}}
{{- lower .Values.gitops.azureProjectName | nospace }}
{{- end }}
{{- define "appName.trim" -}}
{{- (regexReplaceAll "\\W+" .Values.gitops.appName "" | lower) | replace "_" "" }}
{{- end }}