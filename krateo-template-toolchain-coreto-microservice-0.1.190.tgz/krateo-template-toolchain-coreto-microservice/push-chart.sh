#!/bin/bash
set -euo pipefail

chartVersion=$1

echo $chartVersion
if [[  "$chartVersion" =~ [0-9][.][0-9][.][0-9]* ]]; then
    echo "chart version is compliant"
    helm package .
    aws ecr get-login-password --region eu-south-1 | helm registry login --username AWS --password-stdin 420009604339.dkr.ecr.eu-south-1.amazonaws.com
    helm push krateo-template-toolchain-coreto-microservice-$chartVersion.tgz oci://420009604339.dkr.ecr.eu-south-1.amazonaws.com
    rm krateo-template-toolchain-coreto-microservice-$chartVersion.tgz
else
    echo "chart version not compliant"
fi
