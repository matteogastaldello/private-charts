{{- define "azure-project-name.trim" -}}
{{- lower .Values.azureProjectName | nospace }}
{{- end }}