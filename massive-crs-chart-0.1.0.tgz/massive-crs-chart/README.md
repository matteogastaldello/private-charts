massive-crs-chart
=================

This Helm chart renders a configurable number of Custom Resources (CRs) for testing purposes.

Defaults
- count: 100
- name: massive-cr
- cr.apiVersion: testing.example.com/v1alpha1
- cr.kind: TestResource

Install
1. Lint and template locally:
   helm template massive-crs-chart

2. Install:
   helm install massive-crs ./massive-crs-chart -f values.yaml

Notes
- The chart includes a JSON Schema (`values.schema.json`) which validates `count`, `name`, and `cr`.
- Keep `count` reasonable to avoid overwhelming the API server; default 100.
